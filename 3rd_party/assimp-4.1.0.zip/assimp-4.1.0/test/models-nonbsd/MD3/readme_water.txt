-------------------------------------------------------------------------

TITLE : kt_watercan
AUTHOR : ken 'kat' beyer
EMAIL ADDRESS : cpdt@telinco.co.uk
HOMEPAGE URL : http://www.quake3bits.co.uk
NUMBER OF MODELS : 2
SHADER SCRIPTS : n/a

------------------
* MODEL NAME/s *
[model details below]
watercan.md3
watercan_dmg.md3 (dmg='damaged')

water_can.tga 256x128


------------------

CREDITS
ID software, eskimo roll, EMSIPE, QkenneyQ
DISTRIBUTION
as long as this readme is included...!

--------------------------------------------------------------------------