#include "stb_easy_font.h"

void ef_dummy(void)
{
   // suppress unsused-function warning
   stb_easy_font_spacing(0);
   stb_easy_font_print(0,0,0,0,0,0);
   stb_easy_font_width(0);
   stb_easy_font_height(0);
}